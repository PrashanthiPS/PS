
class HomePage {
    constructor() {

        //Login:
    	this.userName = element(by.id('username'));
        this.password = element(by.id('password'));
        this.signonLink = element(by.linkText('Sign On'));
        
       /* //Add New Role
        this.clickOnUserRole = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[2]/a"));
        this.createAssociation = element(by.buttonText('Create Association'));
        this.roleName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[1]/div/div/input"));
        this.description = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[2]/div/div/input"));
        this.acquireDocuments = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[5]/div/div/label/input"));
        this.add = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[2]/app-search-template/div[2]/div/button/span"));
        
        //Add Case Type without Case Type Title.
        this.addCaseType = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[7]/a"));
        this.createCaseType = element(by.buttonText('Create Case Type'));
        this.clickOnSave = element(by.buttonText('SAVE')); */
        
        
        //add Reject reason without reason name 
        this.addRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.createReason = element(by.buttonText('Create Reason'));
        this.clickOnSave = element(by.buttonText('SAVE'));
        
        //Add Reject reason
        this.newRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.writeReason = element(by.buttonText('Create Reason'));
        this.reasonName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[2]/div/div/app-reject-reason-add-edit/app-search-template[2]/div/div/input"));
        this.clickSaveButton = element(by.buttonText('SAVE'));
        this.selectConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmSave = element(by.buttonText('YES'));

       // delete a random reject reason
        this.reasonIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a")); 
        this.reasonToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonYes = element(by.buttonText('DELETE'));
        

        //add Subtype without entering subtype name 
        this.addSubType =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.createSubType = element(by.buttonText('Create Case Subtype'));
        this.saveButton = element(by.buttonText('SAVE'));

        //Add Case Subtype
        this.newCaseSubtype =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.writeSubtype = element(by.buttonText('Create Case Subtype'));
        this.subtypeName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[2]/div/div/app-sub-type-add-edit/app-search-template[2]/div/div/input"));
        this.clickSave = element(by.buttonText('SAVE'));
        this.clickConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmOnSave = element(by.buttonText('YES'));
        
    
       // delete an existing case subtype
        this.subTypeIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.filterIcon = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div/span"));
        this.enterSubtype = element(by.xpath("/html/body/div[2]/div/div[3]/div/div[1]/div/div/div/input"));
        this.applyCondition =element(by.buttonText('APPLY'));
        this.deleteOption= element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.confirmDelete = element(by.buttonText('DELETE')); 

      // delete a random subtype 
        this.subIcon= element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a")); 
        this.subtypeToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.deleteYes = element(by.buttonText('DELETE'));

 /*  //Add Court Group
        this.addCourtGroup =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[5]/a"));
        this.createCourtGroup = element(by.buttonText('Create Court Group'));
        this.clickOnSave = element(by.buttonText('SAVE'));*/
        
        
    }
}


module.exports = new HomePage();