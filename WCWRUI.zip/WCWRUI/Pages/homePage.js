
class HomePage {
    constructor() {

        //Login:
    	this.userName = element(by.id('username'));
        this.password = element(by.id('password'));
        this.signonLink = element(by.linkText('Sign On'));
        
     /*   //Add New Role
        this.clickOnUserRole = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[2]/a"));
        this.createAssociation = element(by.buttonText('Create Association'));
        this.roleName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[1]/div/div/input"));
        this.description = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[2]/div/div/input"));
        this.acquireDocuments = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[5]/div/div/label/input"));
        this.add = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[2]/app-search-template/div[2]/div/button/span"));
      
        //Add Case Type without Case Type Title.
        this.addCaseType = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[7]/a"));
        this.createCaseType = element(by.buttonText('Create Case Type'));
        this.clickOnSave = element(by.buttonText('SAVE')); 
       
 
     // delete a random case type
        this.casetypeIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[7]/a")); 
        this.lastPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-type/div/div/div[1]/app-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        //this.reasonToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteCaseType = element(by.xpath("/html/body/app-root/div/div/div[2]/app-type/div/div/div[1]/app-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.deleteCasetypeYes = element(by.buttonText('DELETE')); 
        
       
        // Update a random case sub type

        this.casesubtypessIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a")); 
        this.lastofPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.casesubtypeUpdate = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.casesubtypeEnter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[2]/div/div/app-sub-type-add-edit/app-search-template[2]/div/div/input"));
        this.saveUpdate = element(by.buttonText('SAVE'));
        this.confirmSaveupdate = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]")); 
*/

/*
       //add Reject reason without reason name 
        this.addRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.createReason = element(by.buttonText('Create Reason'));
        this.clickOnSave = element(by.buttonText('SAVE')); 
        



       //Add Reject reason
        this.newRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.writeReason = element(by.buttonText('Create Reason'));
        this.reasonName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[2]/div/div/app-reject-reason-add-edit/app-search-template[2]/div/div/input"));
        this.clickSaveButton = element(by.buttonText('SAVE'));
        this.selectConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmSave = element(by.buttonText('YES')); 
        

       // delete a random reject reason
        this.reasonIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a")); 
        this.reasonToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonYes = element(by.buttonText('DELETE')); 
        

// update a random reason name 
        this.rejectReasonIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a")); 
       // this.lastofPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.rejectUpdate = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[1]/app-reject-reason-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.reasonEnter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[2]/div/div/app-reject-reason-add-edit/app-search-template[2]/div/div/input"));
        this.savereasonUpdate = element(by.buttonText('SAVE'));
        this.confirmreasonupdate = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]")); 



        //add Subtype without entering subtype name 
        this.addSubType =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.createSubType = element(by.buttonText('Create Case Subtype'));
        this.saveButton = element(by.buttonText('SAVE')); 
       
        //Add Case Subtype

        this.newCaseSubtype =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.writeSubtype = element(by.buttonText('Create Case Subtype'));
        this.subtypeName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[2]/div/div/app-sub-type-add-edit/app-search-template[2]/div/div/input"));
        this.clickSave = element(by.buttonText('SAVE'));
        this.clickConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmOnSave = element(by.buttonText('YES'));
       
     
    
       // delete an existing case subtype

        this.subTypeIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.lastPagesubtype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.enterSubtype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
       
        this.deleteOption= element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.confirmDelete = element(by.buttonText('DELETE'));
      
/*
      // delete a random subtype 
        this.subIcon= element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a")); 
        this.subtypeToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.deleteYes = element(by.buttonText('DELETE'));
        expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');

      //delete a random user
       	 
	 // delete user (active /inactive)
		 
		this.usersTab = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
		this.findUser = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]/div/span")); 
		//this.clickUser = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[3]/div[6]"));
		this.checkBox = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[1]/div/div/label/input"));
		this.updateUser = element(by.buttonText('UPDATE'));
		this.mailConfirm = element(by.buttonText('Send Mail'));
		
		 //Add new user (admin)
	     this.userIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
         this.createButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[1]/button"));
         this.createAdmin = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[2]/button[1]"));
         this.firstName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[1]/div/input"));
         this.lastName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[2]/div/input"));
         this.enterEmail = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[3]/div/div/input"));
         this.loginId = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[4]/div/div/input"));
         this.selectCalendar = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/button/i"));
       //  this.prevMonth = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[1]/ngb-datepicker-navigation/button[1]/span"));
         this.datePicker = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[5]/div"));
         this.createButtontwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[2]/app-search-template/div[2]/div/button/span"));
         this.confirmEmailButton = element(by.buttonText('Send Mail'));
         expect(element(by.css('.alert-container')).getText()).toEqual('The following User with Login ID APM094 has been successfully Created');

         //Add new user (case manager)

        this.usersIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
        this.createnewButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[1]/button"));
        this.createCasemanager =element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[2]/button[2]"));
        this.firstNamebutton =element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[1]/div/input"));
        this.lastNamebutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[2]/div/input"));
        this.emailButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[3]/div/div/input"));
        this.loginIdButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[4]/div/div/input"));
        this.selectCalendarButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/button/i"));
        this.datePickersafebday = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[5]/div"));
        this.selectrolesButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/button"));
        this.searchrole = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/bento-multiselect-list/div/input"));
        this.selectAll = element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/bento-multiselect-list/bento-list-core/div[1]/div/div[2]/i"));
        this.doneButton = element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/div/button"));
        this.courtsTab = element(by.xpath ("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[2]/div/div/button"));
        this.checkBox = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[8]/div/div/div/div/div/bento-checkbox/input"));
        this.courtDonebutton = element (by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
        this.superCasetype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[7]/div[2]/div/div/button"));
        this.selectCheckbox = element (by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[8]/div/div/div/div/div/bento-checkbox/input"));
        this.selectionDone = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
        this.createcasemanagerButton =element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[2]/app-search-template/div[2]/div/button"));
        this.confirmpopButton = element(by.buttonText('Send Mail'));
        expect(element(by.css('.alert-container')).getText()).toEqual('The following User with Login ID APM094 has been successfully Created');




       //Create child court
       this.courtIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[3]/a"));
       this.firstCreatecourt = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[1]/div[1]/button"));
       this.childCourtbutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div/app-search-template/div/div/div[1]/label/div[2]/label"));
       this.parentCourts = element (by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div/app-search-template/div/div/div[1]/label/div[2]/div/app-search-template/div/div/div[1]/div[2]/select"));
       //this.selectParentCourt = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div/app-search-template/div/div/div[1]/label/div[2]/div/app-search-template/div/div/div[1]/div[2]/div[2]"));
       this.selectParentCourt = element(by.cssContainingText('option', 'testing'));
       this.enterDisplayName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div[2]/app-search-template[3]/div/div/input"));
       this.enterNextcaseNumber = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div[2]/app-search-template[5]/div/div/input"));
       this.enterDocketformat = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div[2]/app-search-template[6]/div/div/input"));
       this.enterSample = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div[2]/app-search-template[7]/div/div/input"));
       this.createButtonone = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[2]/app-search-template/div[2]/div/button"));
       this.suretoUpdate = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));


       // create child court negative scenario

       this.courtIconadmin = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[3]/a"));
       this.Createcourttop= element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[1]/div[1]/button"));
       this.childCourtradiobutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[1]/div/app-search-template/div/div/div[1]/label/div[2]/label"));
       this.createButtonend = element(by.xpath("/html/body/app-root/div/div/div[2]/app-courts/div/div/div[2]/div/app-create-court/div/div/div[2]/app-search-template/div[2]/div/button"));
    



// Admin user adds teamlead to a team
      
       this.teamsTab = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[4]/a"));
       this.selectTeam =element(by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
       this.usersTabclick = element (by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[2]/div/div/div[1]/app-search-template[3]/div/div/div/button"));
       this.leadIcon = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[5]/div/i/span"));
       this.doneButtonteam = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
       this.updateButtonteam = element(by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[2]/div/div/div[2]/app-search-template/div[2]/div/button/span"));


        //Admin user adds multiple team leads to the team
       
       this.teamsTabforMultiple = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[4]/a"));
       this.selectTeamMultiple =element(by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
       this.usersTabclickMultiple = element (by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[2]/div/div/div[1]/app-search-template[3]/div/div/div/button"));
       this.leadIconMultiple = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[5]/div/i/span"));
       
       this.leadIcontwo = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[5]/div/i/span"));
       this.doneButtonteamMultiple = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
       this.updateButtonteamMulti  = element(by.xpath("/html/body/app-root/div/div/div[2]/app-teams/div/div/div[2]/div/div/div[2]/app-search-template/div[2]/div/button/span"));

// Case manager accepts a case without PDF (Proceed without PDF)


       this.profileIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.switchToCasemanager = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelectionIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFilter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFilter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.searchCourt = element(by.xpath("/html/body/div[2]/div/div[3]/div/div[1]/div/div/div/input"));

       this.bronxCourt = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       this.selectCase = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]/div"));
      



       this.acceptRadiobutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/label"));
       this.casetypeSelect = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/div/app-search-template/div[1]/div/div[1]/div[2]"));
       this.selectType =  element(by.cssContainingText('option', 'Administrative'));
       this.proceedWithoutpdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/div/app-search-template/div[3]/div/label/input"));
       this.submitCase = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));



// case manager accepts multiple cases from case selection 

       this.profileIcontwo = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.switchToCasemanagertwo = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelectionIcontwo = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFiltertwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFiltertwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.searchCourttwo = element(by.xpath("/html/body/div[2]/div/div[3]/div/div[1]/div/div/div/input"));
       this.bronxCourttwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       
       this.selectCaseone = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[5]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[5]/div[1]/div/span"));

       this.selectCasetwo = element (by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[5]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[9]/div[1]/div/span"));
       this.selectCasethree = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[5]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[10]/div[1]/div/span"));
       this.selectCasefour = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[5]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[11]/div[1]"));
       this.acceptRadiobuttontwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/label"));
       this.casetypeSelecttwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/div/app-search-template/div[1]/div/div[1]/div[2]"));
       this.selectTypetwo =  element(by.cssContainingText('option', 'Administrative'));
       this.proceedWithoutpdftwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/div/app-search-template/div[3]/div/label/input"));
       this.submitCasetwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));

//case manager rejects a case  from case selection screen


       this.profileIconrej = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.switchToCasemanagerrej = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelectionIconrej = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFilterrej = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFilterrej = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       //this.searchCourtrej = element(by.xpath("/html/body/div[2]/div/div[3]/div/div[1]/div/div/div/input"));
       this.randomCourtrej = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       this.selectCaserej = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[6]/div[1]/div"));
       this.rejectRadiobutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[3]/label"));
       this.rejectReasonbutton =  element(by.cssContainingText('option', 'new reason'));
       this.submitCasereject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));


// NO PDF yet recheck later scenario 
       
       this.profileIconnopdf = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.switchToCasemanagernopdf = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelectionIconnopdf = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFilternopdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFilternopdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.randomCourtnopdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       this.selectCasenopdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[6]/div[1]/div"));
       this.noPDFyetbutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[2]/label"));
       this.submitCasenopdf = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));
    

// Not assigned by the court 


 
       this.profileIconassigned = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.switchToCasemanagerassigned = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelectionIconnotassigned = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFilternotassigned = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFilternotassigned = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.randomCourtnotassigned = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       this.selectCasenotassigned = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[6]/div[1]/div"));
       this.notassignedyetbutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[1]/label"));
       this.submitCasenotassigned = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));
    


// Not assigned by the court 


 
       this.profilenotqualified = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.swtchToCasemngrntquali= element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelecnntquali = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFilterntquali = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFilterntquali = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.randomCourtntquali = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       this.selectCasentquali = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[6]/div[1]/div"));
       this.ntqualified = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[3]/app-search-template/div/div/div[1]/label/div[5]/label"));
       this.submitCasentquali = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));
    
*/
//multicase reject option 

      
       
       this.profilemulticasereject  = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[2]/li[2]/div/span/a/img"));
       this.swtchToCasemulticasereject = element(by.xpath("//span[text()='Switch to Case Manager']"));
       this.caseSelecnmultireject = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/div/li[5]/a"));
       this.enableFiltermultireject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[1]/button/i"));
       this.courtFiltermultireject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[6]/div/div/div[1]/div"));
       this.randomCourtmultireject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[12]/div[1]"));
       //this.selectCasemultireject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[6]/div[1]/div"));
       this.multiCasereject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/button"));
       this.multiCheckbox = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[5]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[8]/div/div/div/div/div/bento-checkbox/input"));
       this.selectAction = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/div[2]/button"));
       this.rejectMulti = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[1]/div[2]/app-search-template/div/div/div[1]/label/div[4]/label"));
       this.submitCasemultireject = element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[2]/div/div/app-edit-case/div[2]/app-search-template[2]/div[2]/div/button/span"));
    


}
}
module.exports = new HomePage();