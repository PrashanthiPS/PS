class DeleteUser{
	 constructor(){
		 
	 // delete user (active /inactive)
		 
		this.usersTab = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
		this.findUser = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[7]/div[1]/div/span")); 
		this.clickUser = element(by.buttonText('Active'));
		this.checkBox = element(by.linkText('Active User'));
		this.updateUser = element(by.buttonText('UPDATE'));
		this.mailConfirm = element(by.buttonTest('SEND MAIL'));
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	  }

}
module.exports = new DeleteUser();










