//import { browser, element, by, ElementFinder} from 'protractor'
var homePage = require('../Pages/homePage');
var testdata = require('../Testdata/data.json');
const EC = protractor.ExpectedConditions;

  describe('WCWRUI Homepage', function () {
	

  it('HomePageTest - It should navigate to WCWR home page!', function () {

	browser.ignoreSynchronization = true;
	browser.waitForAngularEnabled(false);
    browser.driver.manage().window().maximize();
    browser.get(testdata.environment);
    browser.sleep(6000);
    
	homePage.userName.sendKeys(testdata.Username);
	browser.sleep(3000);
	homePage.password.sendKeys(testdata.Password);
	browser.sleep(3000);
	homePage.signonLink.click();
	 //browser.sleep(20000);
	 //element(by.linkText("Allow")).click();
	 browser.sleep(30000);


     //Read titile
    //expect(browser.getTitle()).toEqual("WCWRUI");

      });
  
  /* it('HomePageTest - It should Add New Role!', function(){
	  
	  //browser.ignoreSynchronization = false;
	  
	  homePage.clickOnUserRole.click();
	  browser.sleep(3000);
	  homePage.createAssociation.click();
	  browser.sleep(3000);
	  homePage.roleName.sendKeys(testdata.roleName);
	  browser.sleep(3000);
	  homePage.description.sendKeys(testdata.description);
	  browser.sleep(3000);
	  homePage.acquireDocuments.click();
	  browser.sleep(3000);
	  homePage.add.click();
	  
	  //expect(homePage.roleName.Text()).toContain('AAA');
	  
	  
  });
 
    it('HomePageTest - It should add Case Type', function(){
	   
	  homePage.addCaseType.click();
	  browser.sleep(3000);
	  homePage.createCaseType.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(1000);
	  
	  expect(element(by.css('.alert-container')).getText()).toEqual('Title Type cannot be empty');

	    

  it('HomePageTest - It should delete a random Case type Name', function(){
	   
	  homePage.casetypeIcon.click();
	  browser.sleep(3000);
      homePage.lastPage.click();
      browser.sleep(3000);
	//  homePage.subtypeToDelete.click();
	 // browser.sleep(3000);
	  homePage.deleteCaseType.click();
	  browser.sleep(3000);
	  homePage.deleteCasetypeYes.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Type deleted');
       });

	 it('HomePageTest - It should update a random Case sub type Name', function(){
	   
	  homePage.casesubtypessIcon.click();
	  browser.sleep(3000);
      homePage.lastofPage.click();
      browser.sleep(3000);
	  homePage.casesubtypeUpdate.click();
	  browser.sleep(3000);
	  homePage.casesubtypeEnter.sendKeys(testdata.caseupdates);
	  browser.sleep(3000);
      homePage.saveUpdate.click();
      browser.sleep(3000);
      homePage.confirmSaveupdate.click();
      browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Type updated/added');
       }); 
  /*
   it('HomePageTest - It should add Reject Reason', function(){
	   
	  homePage.addRejectReason.click();
	  browser.sleep(3000);
	  homePage.createReason.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('REASON NAME cannot be empty');
   });
	  
   it('HomePageTest - It should add a Reject Reason', function(){
	   
	  homePage.newRejectReason.click();
	  browser.sleep(3000);
	  homePage.writeReason.click();
	  browser.sleep(3000);
	  homePage.reasonName.sendKeys(testdata.reason);
	  homePage.clickSaveButton.click();
	  browser.sleep(3000);
	  homePage.selectConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmSave.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason updated/added'); 
  }); 


  // update reject reason 

	 it('HomePageTest - It should update a randomReject reason  Name', function(){
	   
	  homePage.rejectReasonIcon.click();
	  browser.sleep(3000);
      
	  homePage.rejectUpdate.click();
	  browser.sleep(3000);
	  homePage.reasonEnter.sendKeys(testdata.caseupdates);
	  browser.sleep(3000);
      homePage.savereasonUpdate.click();
      browser.sleep(3000);
      homePage.confirmreasonupdate.click();
      browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason updated/added');
       }); 




  it('HomePageTest - It should delete a random  Reason Name', function(){
	   
	  homePage.reasonIcon.click();
	  browser.sleep(3000);
	  homePage.reasonToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteReasonSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteReasonYes.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason deleted');
	  
       });

   it('HomePageTest - It should add Case Subtype', function(){
	   
	  homePage.addSubType.click();
	  browser.sleep(3000);
	  homePage.createSubType.click();
	  browser.sleep(3000);
	  homePage.saveButton.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Type updated/added');
   });  
	   
   it('HomePageTest - It should add a Subtype Name', function(){
	   
	  homePage.newCaseSubtype.click();
	  browser.sleep(3000);
	  homePage.writeSubtype.click();
	  browser.sleep(3000);
	  homePage.subtypeName.sendKeys(testdata.subtype);
	  homePage.clickSave.click();
	  browser.sleep(3000);
	  homePage.clickConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmOnSave.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');

	   });

   */ // new code !!
  /*    it('HomePageTest - It should delete a Subtype', function() {
	
	  homePage.subTypeIcon.click();
	  browser.sleep(3000);
	  homePage.lastPagesubtype.click();
	  browser.sleep(3000);
	  homePage.enterSubtype.click();
      browser.sleep(3000);
	 
	  homePage.deleteOption.click();
	  browser.sleep(3000);
	  homePage.confirmDelete.click();
	  browser.sleep(3000); 
      expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');
   }); 


     it('HomePageTest - It should delete a random  Subtype Name', function(){
	   
	  homePage.subIcon.click();
	  browser.sleep(3000);
	  homePage.subtypeToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteYes.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted')
       });

*/
	 
	 // delete user (active /inactive)
	/*	 
	it('HomePageTest - It should delete a random User Name', function(){
	   
	  homePage.usersTab.click();
	  browser.sleep(5000);
	  homePage.findUser.click();
	  browser.sleep(3000);
	  homePage.checkBox.click();
	  browser.sleep(3000);
      homePage.updateUser.click();
	  browser.sleep(3000);
      homePage.mailConfirm.click();
	  browser.sleep(3000);
	  
       });

 // delete user (active /inactive)
		 
 it('HomePageTest - It should add adminUser', function(){
	   
	  homePage.userIcon.click();
	  browser.sleep(5000);
	  homePage.createButton.click();
	  browser.sleep(3000);
	  homePage.createAdmin.click();
	  browser.sleep(3000);
      homePage.firstName.sendKeys(testdata.name);
	  browser.sleep(3000);
      homePage.lastName.sendKeys(testdata.lasttname);
	  browser.sleep(3000);
	  homePage.enterEmail.sendKeys(testdata.mailid);
      browser.sleep(3000);
      homePage.loginId.sendKeys(testdata.lognid);
      browser.sleep(3000);
      homePage.selectCalendar.click();
      browser.sleep(3000);
      homePage.datePicker.click();
      browser.sleep(3000);
     // homePage.prevMonth.click();
     // browser.sleep(3000);
      homePage.createButtontwo.click();
      browser.sleep(3000);
      homePage.confirmEmailButton.click();
      browser.sleep(3000);
       });   
		 
	it('HomePageTest - It should add casemanager', function(){
	   
	  homePage.usersIcon.click();
	  browser.sleep(5000);
	  homePage.createnewButton.click();
	  browser.sleep(3000);
      homePage.createCasemanager.click();
	  browser.sleep(3000);
      homePage.firstNamebutton.sendKeys(testdata.firstNamebutton);
	  browser.sleep(3000);
      homePage.lastNamebutton.sendKeys(testdata.lastNamebutton);
	  browser.sleep(3000);
	  homePage.emailButton.sendKeys(testdata.mailid);
      browser.sleep(3000);
      homePage.loginIdButton.sendKeys(testdata.loginIdButton);
      browser.sleep(3000);
      homePage.selectCalendarButton.click();
      browser.sleep(3000);
      homePage.datePickersafebday.click();
      browser.sleep(3000);
      homePage.selectrolesButton.click();
      browser.sleep(3000);
      homePage.searchrole.sendKeys(testdata.searchRole);
      browser.sleep(3000);
      homePage.selectAll.click();
      browser.sleep(3000);
     // homePage.selectAll.click();
      //browser.sleep(3000);
      homePage.doneButton.click();
      browser.sleep(3000);
      homePage.courtsTab.click();
      browser.sleep(3000);
      homePage.checkBox.click();
      browser.sleep(3000);
      homePage.courtDonebutton.click();
      browser.sleep(3000);
      homePage.superCasetype.click();
      browser.sleep(3000);
      homePage.selectCheckbox.click();
      browser.sleep(3000);
      homePage.selectionDone.click();
      browser.sleep(3000);
      homePage.createcasemanagerButton.click();
      browser.sleep(3000);
      homePage.confirmpopButton.click();
      browser.sleep(3000);



	 
 it('HomePageTest - It should add new child court', function(){
	   
	  homePage.courtIcon.click();
	  browser.sleep(5000);
	  homePage.firstCreatecourt.click();
	  browser.sleep(3000);
      homePage.childCourtbutton.click();
	  browser.sleep(5000);
      homePage.parentCourts.click();
	  browser.sleep(3000);
      homePage.selectParentCourt.click();
	  browser.sleep(3000);
	  homePage.enterDisplayName.sendKeys(testdata.childcourtname);
      browser.sleep(3000);
      homePage.enterNextcaseNumber.sendKeys(testdata.nextcase);
      browser.sleep(3000);
      homePage.enterDocketformat.sendKeys(testdata.docketformat);
      browser.sleep(3000);
      homePage.enterSample.sendKeys(testdata.samplecase);
      browser.sleep(3000);
      homePage.createButtonone.click();
      browser.sleep(3000); 
      homePage.suretoUpdate.click();
      browser.sleep(3000);    
})

    it('HomepageTest -It should click on create child court without entering a value',function(){
      homePage.courtIconadmin.click();
	  browser.sleep(3000);
	  homePage.Createcourttop.click();
	  browser.sleep(3000);
      homePage.childCourtradiobutton.click();
	  browser.sleep(5000);
      homePage.createButtonend.click();
      browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Please fill all mandatory fields'); 
})


    it('HomepageTest -It should allow user to add teamlead to a team',function(){
      homePage.teamsTab.click();
	  browser.sleep(3000);
	  homePage.selectTeam.click();
	  browser.sleep(3000);
      homePage.usersTabclick.click();
	  browser.sleep(3000);
  // if{ (element(by.xpath ("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[5]/div/i/span")).isSelected() == false) {
     // homePage.leadIcon.click();
//}
      homePage.leadIcon.click();
      browser.sleep(3000);
      homePage.doneButtonteam.click();
      browser.sleep(3000);
      homePage.updateButtonteam.click();
      browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Team updated Successfully'); 
})



    it('HomepageTest -It should allow user to add multiple teamleads  to a team',function(){
	
      homePage.teamsTabforMultiple.click();
	  browser.sleep(3000);
	  homePage.selectTeamMultiple.click();
	  browser.sleep(3000);
      homePage.usersTabclickMultiple.click();
	  browser.sleep(3000);
  
      homePage.leadIconMultiple.click();
      browser.sleep(3000);
      //browser.executeScript("return document.Set as Lead Contact");
     var sampleTextBox2 = homePage.leadIcontwo; 
     browser.executeScript("arguments[0].scrollIntoView();", sampleTextBox2); 
     sampleTextBox2.click();

     homePage.leadIcontwo.click();
      browser.sleep(3000);
      homePage.doneButtonteamMultiple.click();
      browser.sleep(3000);
      homePage.updateButtonteamMulti.click();
      browser.sleep(1000);
      //expect(element(by.css('.alert-container')).getText()).toEqual('Team updated Successfully'); 



    it('HomepageTest -Case selection screen  , accept case without PDF',function(){
	
      homePage.profileIcon.click();
	  browser.sleep(3000);
	  homePage.switchToCasemanager.click();
	  browser.sleep(3000);
      homePage.caseSelectionIcon.click();
	  browser.sleep(3000);
      homePage.bronxCourt.click();
      browser.sleep(3000);
     
      homePage.selectCase.click();
      browser.sleep(3000);
      homePage.acceptRadiobutton.click();
      browser.sleep(3000);
      homePage.casetypeSelect.click();
      browser.sleep(3000);
      homePage.selectType.click();
      browser.sleep(3000);
      homePage.proceedWithoutpdf.click();
      browser.sleep(3000);
      homePage.submitCase.click();
      browser.sleep(1000);
      //expect(element(by.css('.alert-container')).getText()).toEqual('Team updated Successfully'); 


    

    it('HomepageTest -Case selection screen  , accept multiple cases without PDF',function(){
	
      homePage.profileIcontwo.click();
	  browser.sleep(3000);
	  homePage.switchToCasemanagertwo.click();
	  browser.sleep(3000);
      homePage.caseSelectionIcontwo.click();
	  browser.sleep(3000);
      homePage.bronxCourttwo.click();
      browser.sleep(3000);
 
      homePage.selectCaseone.click();
      browser.sleep(3000);
      homePage.acceptRadiobuttontwo.click();
      browser.sleep(3000);
      homePage.casetypeSelecttwo.click();
      browser.sleep(3000);
      homePage.selectTypetwo.click();
      browser.sleep(3000);
      homePage.proceedWithoutpdftwo.click();
      browser.sleep(3000);
      homePage.submitCasetwo.click();
      browser.sleep(3000);
      

      homePage.selectCasetwo.click();
      browser.sleep(3000);
      homePage.acceptRadiobuttontwo.click();
      browser.sleep(3000);
      homePage.casetypeSelecttwo.click();
      browser.sleep(3000);
      homePage.selectTypetwo.click();
      browser.sleep(3000);
      homePage.proceedWithoutpdftwo.click();
      browser.sleep(3000);
      homePage.submitCasetwo.click();
      browser.sleep(1000);


      homePage.selectCasethree.click();
      browser.sleep(3000);
      homePage.acceptRadiobuttontwo.click();
      browser.sleep(3000);
      homePage.casetypeSelecttwo.click();
      browser.sleep(3000);
      homePage.selectTypetwo.click();
      browser.sleep(3000);
      homePage.proceedWithoutpdftwo.click();
      browser.sleep(3000);
      homePage.submitCasetwo.click();
      browser.sleep(1000);




      homePage.selectCasefour.click();
      browser.sleep(3000);
      homePage.acceptRadiobuttontwo.click();
      browser.sleep(3000);
      homePage.casetypeSelecttwo.click();
      browser.sleep(3000);
      homePage.selectTypetwo.click();
      browser.sleep(3000);
      homePage.proceedWithoutpdftwo.click();
      browser.sleep(3000);
      homePage.submitCasetwo.click();
      browser.sleep(1000);


    // browser.actions().mouseMove(element(by.xpath("/html/body/app-root/div/div/div[2]/app-court-schedule-list/div/div/div[1]/div[4]/app-case-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]/div"))).perform()
	});



 
  
    //describe('Protractor Typescript Demo', function() {
	//browser.ignoreSynchronization = true; // for non-angular websites
	//browser.manage().window().maximize()
	//it('Mouse Operations', function() {
		// set implicit time to 30 seconds
		//browser.manage().timeouts().implicitlyWait(30000);

		//browser.get("https://chercher.tech/practice/popups")
		// mouse hover on a submenu
		
		
		
	 it('HomepageTest -Case selection screen  , Reject a case ',function(){
	
      homePage.profileIconrej.click();
	  browser.sleep(3000);
	  homePage.switchToCasemanagerrej.click();
	  browser.sleep(3000);
      homePage.caseSelectionIconrej.click();
	  browser.sleep(3000);
      homePage.enableFilterrej.click();
      browser.sleep(3000);
     
      homePage.courtFilterrej.click();
      browser.sleep(3000);
    //  homePage.searchCourtrej.click();
     // browser.sleep(3000);
      homePage.randomCourtrej.click();
      browser.sleep(3000);
      homePage.selectCaserej.click();
      browser.sleep(3000);
      homePage.rejectRadiobutton.click();
      browser.sleep(3000);
      homePage.rejectReasonbutton.click();
      browser.sleep(1000);	
      homePage.submitCasereject.click();
      browser.sleep(3000);


  it('HomepageTest -Case selection screen  , NO PDF yet recheck later  ',function(){
	
      homePage.profileIconnopdf.click();
	  browser.sleep(3000);
	  homePage.switchToCasemanagernopdf.click();
	  browser.sleep(3000);
      homePage.caseSelectionIconnopdf.click();
	  browser.sleep(3000);
      homePage.enableFilternopdf.click();
      browser.sleep(3000);
     
      homePage.courtFilternopdf.click();
      browser.sleep(3000);
    //  homePage.searchCourtrej.click();
     // browser.sleep(3000);
      homePage.randomCourtnopdf.click();
      browser.sleep(3000);
      homePage.selectCasenopdf.click();
      browser.sleep(3000);
      homePage.noPDFyetbutton.click();
      browser.sleep(3000);
      homePage.submitCasenopdf.click();
      browser.sleep(3000);


it('HomepageTest -Case selection screen  , Not assigned by the court ',function(){
	
      homePage.profileIconassigned.click();
	  browser.sleep(3000);
	  homePage.switchToCasemanagerassigned.click();
	  browser.sleep(3000);
      homePage.caseSelectionIconnotassigned.click();
	  browser.sleep(3000);
      homePage.enableFilternotassigned.click();
      browser.sleep(3000);
     
      homePage.courtFilternotassigned.click();
      browser.sleep(3000);
   
      homePage.randomCourtnotassigned.click();
      browser.sleep(3000);
      homePage.selectCasenotassigned.click();
      browser.sleep(3000);
      homePage.notassignedyetbutton.click();
      browser.sleep(3000);
      homePage.submitCasenotassigned.click();
      browser.sleep(3000);


it('HomepageTest -Case selection screen  , Not qualified,but acceptable if necessary ',function(){
	
      homePage.profilenotqualified.click();
	  browser.sleep(3000);
	  homePage.swtchToCasemngrntquali.click();
	  browser.sleep(3000);
      homePage.caseSelecnntquali.click();
	  browser.sleep(3000);
      homePage.enableFilterntquali.click();
      browser.sleep(3000);
      homePage.courtFilterntquali.click();
      browser.sleep(3000);
      homePage.randomCourtntquali.click();
      browser.sleep(3000);
      homePage.selectCasentquali.click();
      browser.sleep(3000);
      homePage.ntqualified.click();
      browser.sleep(3000);
      homePage.submitCasentquali.click();
      browser.sleep(3000);





*/



it('HomepageTest -Case selection screen  , multicase reject option  ',function(){
	
      homePage.profilemulticasereject.click();
	  browser.sleep(3000);
	  homePage.swtchToCasemulticasereject.click();
	  browser.sleep(3000);
      homePage.caseSelecnmultireject.click();
	  browser.sleep(3000);
      homePage.enableFiltermultireject.click();
      browser.sleep(3000);
      homePage.courtFiltermultireject.click();
      browser.sleep(3000);
      homePage.randomCourtmultireject.click();
      browser.sleep(3000);
     // homePage.selectCasemultireject.click();
    // browser.sleep(3000);
      homePage.multiCasereject.click();
      browser.sleep(3000);
      homePage.multiCheckbox.click();
      browser.sleep(3000);
      homePage.selectAction.click();
      browser.sleep(3000);
      homePage.rejectMulti.click();
      browser.sleep(3000);
      homePage.submitCasemultireject .click();
      browser.sleep(3000);
})
});

//});
