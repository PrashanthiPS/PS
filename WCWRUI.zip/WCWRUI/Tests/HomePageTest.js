var homePage = require('../Pages/homePage');
var testdata = require('../Testdata/data.json');
const EC = protractor.ExpectedConditions;


  describe('WCWRUI Homepage', function () {
	

  it('HomePageTest - It should navigate to WCWR home page!', function () {

	browser.ignoreSynchronization = true;
    browser.driver.manage().window().maximize();
    browser.get(testdata.environment);
    browser.sleep(6000);
    
	homePage.userName.sendKeys(testdata.Username);
	browser.sleep(3000);
	homePage.password.sendKeys(testdata.Password);
	browser.sleep(3000);
	homePage.signonLink.click();
	 //browser.sleep(20000);
	 //element(by.linkText("Allow")).click();
	 browser.sleep(30000);


     //Read titile
    //expect(browser.getTitle()).toEqual("WCWRUI");

      });
  
  /* it('HomePageTest - It should Add New Role!', function(){
	  
	  //browser.ignoreSynchronization = false;
	  
	  homePage.clickOnUserRole.click();
	  browser.sleep(3000);
	  homePage.createAssociation.click();
	  browser.sleep(3000);
	  homePage.roleName.sendKeys(testdata.roleName);
	  browser.sleep(3000);
	  homePage.description.sendKeys(testdata.description);
	  browser.sleep(3000);
	  homePage.acquireDocuments.click();
	  browser.sleep(3000);
	  homePage.add.click();
	  
	  //expect(homePage.roleName.Text()).toContain('AAA');
	  
	  
  });
  
  it('HomePageTest - It should add Case Type', function(){
	   
	  homePage.addCaseType.click();
	  browser.sleep(3000);
	  homePage.createCaseType.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(3000);
	  
	  //expect(homePage.roleName.Text()).toContain('AAA'); */
	    
	  
  
   it('HomePageTest - It should add Reject Reason', function(){
	   
	  homePage.addRejectReason.click();
	  browser.sleep(3000);
	  homePage.createReason.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(3000);
   });
	  
   it('HomePageTest - It should add a Reject Reason', function(){
	   
	  homePage.newRejectReason.click();
	  browser.sleep(3000);
	  homePage.writeReason.click();
	  browser.sleep(3000);
	  homePage.reasonName.sendKeys(testdata.reason);
	  homePage.clickSaveButton.click();
	  browser.sleep(3000);
	  homePage.selectConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmSave.click();
	  browser.sleep(3000);
	  
  });
  
  it('HomePageTest - It should delete a random  Reason Name', function(){
	   
	  homePage.reasonIcon.click();
	  browser.sleep(3000);
	  homePage.reasonToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteReasonSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteReasonYes.click();
	  browser.sleep(3000);
	  
       });

   it('HomePageTest - It should add Case Subtype', function(){
	   
	  homePage.addSubType.click();
	  browser.sleep(3000);
	  homePage.createSubType.click();
	  browser.sleep(3000);
	  homePage.saveButton.click();
	  browser.sleep(3000);
   });  
	   
   it('HomePageTest - It should add a Subtype Name', function(){
	   
	  homePage.newCaseSubtype.click();
	  browser.sleep(3000);
	  homePage.writeSubtype.click();
	  browser.sleep(3000);
	  homePage.subtypeName.sendKeys(testdata.subtype);
	  homePage.clickSave.click();
	  browser.sleep(3000);
	  homePage.clickConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmOnSave.click();
	  browser.sleep(3000);

	   });

    /*it('HomePageTest - It should delete a Subtype', function() {
	
	  homePage.subTypeIcon.click();
	  browser.sleep(3000);
	  homePage.filterIcon.click();
	  browser.sleep(3000);
	  homePage.enterSubtype.sendKeys(testdata.subtype);
      browser.sleep(3000);
	  homePage.applyCondition.click();
	  browser.sleep(3000);
	  homePage.deleteOption.click();
	  browser.sleep(3000);
	  homePage.confirmDelete.click();
	  browser.sleep(3000); 
   }); */
     it('HomePageTest - It should delete a random  Subtype Name', function(){
	   
	  homePage.subIcon.click();
	  browser.sleep(3000);
	  homePage.subtypeToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteYes.click();
	  browser.sleep(3000);
	  
       });

 });