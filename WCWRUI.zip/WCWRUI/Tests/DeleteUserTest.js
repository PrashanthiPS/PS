var deleteUser = require('../Pages/deleteUser');
var testcasedata = require('../Testdata/data.json');
const EC = protractor.ExpectedConditions;


it('DeleteUserTest - It should make a user active/inactive', function(){
	
  deleteUser.usersTab.click();
  browser.sleep(3000);
  deleteUser.findUser.click();
  browser.sleep(3000);
  deleteUser.clickUser.click();
  browser.sleep(3000);
  deleteUser.checkBox.click();
  browser.sleep(3000);
  deleteUser.updateUser.click();
  browser.sleep(3000);
  deleteUser.mailConfirm.click();
  broser.sleep(3000);


	  
});