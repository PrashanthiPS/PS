var app = angular.module('reportingApp', []);

//<editor-fold desc="global helpers">

var isValueAnArray = function (val) {
    return Array.isArray(val);
};

var getSpec = function (str) {
    var describes = str.split('|');
    return describes[describes.length - 1];
};
var checkIfShouldDisplaySpecName = function (prevItem, item) {
    if (!prevItem) {
        item.displaySpecName = true;
    } else if (getSpec(item.description) !== getSpec(prevItem.description)) {
        item.displaySpecName = true;
    }
};

var getParent = function (str) {
    var arr = str.split('|');
    str = "";
    for (var i = arr.length - 2; i > 0; i--) {
        str += arr[i] + " > ";
    }
    return str.slice(0, -3);
};

var getShortDescription = function (str) {
    return str.split('|')[0];
};

var countLogMessages = function (item) {
    if ((!item.logWarnings || !item.logErrors) && item.browserLogs && item.browserLogs.length > 0) {
        item.logWarnings = 0;
        item.logErrors = 0;
        for (var logNumber = 0; logNumber < item.browserLogs.length; logNumber++) {
            var logEntry = item.browserLogs[logNumber];
            if (logEntry.level === 'SEVERE') {
                item.logErrors++;
            }
            if (logEntry.level === 'WARNING') {
                item.logWarnings++;
            }
        }
    }
};

var convertTimestamp = function (timestamp) {
    var d = new Date(timestamp),
        yyyy = d.getFullYear(),
        mm = ('0' + (d.getMonth() + 1)).slice(-2),
        dd = ('0' + d.getDate()).slice(-2),
        hh = d.getHours(),
        h = hh,
        min = ('0' + d.getMinutes()).slice(-2),
        ampm = 'AM',
        time;

    if (hh > 12) {
        h = hh - 12;
        ampm = 'PM';
    } else if (hh === 12) {
        h = 12;
        ampm = 'PM';
    } else if (hh === 0) {
        h = 12;
    }

    // ie: 2013-02-18, 8:35 AM
    time = yyyy + '-' + mm + '-' + dd + ', ' + h + ':' + min + ' ' + ampm;

    return time;
};

var defaultSortFunction = function sortFunction(a, b) {
    if (a.sessionId < b.sessionId) {
        return -1;
    } else if (a.sessionId > b.sessionId) {
        return 1;
    }

    if (a.timestamp < b.timestamp) {
        return -1;
    } else if (a.timestamp > b.timestamp) {
        return 1;
    }

    return 0;
};

//</editor-fold>

app.controller('ScreenshotReportController', ['$scope', '$http', 'TitleService', function ($scope, $http, titleService) {
    var that = this;
    var clientDefaults = {};

    $scope.searchSettings = Object.assign({
        description: '',
        allselected: true,
        passed: true,
        failed: true,
        pending: true,
        withLog: true
    }, clientDefaults.searchSettings || {}); // enable customisation of search settings on first page hit

    this.warningTime = 1400;
    this.dangerTime = 1900;
    this.totalDurationFormat = clientDefaults.totalDurationFormat;
    this.showTotalDurationIn = clientDefaults.showTotalDurationIn;

    var initialColumnSettings = clientDefaults.columnSettings; // enable customisation of visible columns on first page hit
    if (initialColumnSettings) {
        if (initialColumnSettings.displayTime !== undefined) {
            // initial settings have be inverted because the html bindings are inverted (e.g. !ctrl.displayTime)
            this.displayTime = !initialColumnSettings.displayTime;
        }
        if (initialColumnSettings.displayBrowser !== undefined) {
            this.displayBrowser = !initialColumnSettings.displayBrowser; // same as above
        }
        if (initialColumnSettings.displaySessionId !== undefined) {
            this.displaySessionId = !initialColumnSettings.displaySessionId; // same as above
        }
        if (initialColumnSettings.displayOS !== undefined) {
            this.displayOS = !initialColumnSettings.displayOS; // same as above
        }
        if (initialColumnSettings.inlineScreenshots !== undefined) {
            this.inlineScreenshots = initialColumnSettings.inlineScreenshots; // this setting does not have to be inverted
        } else {
            this.inlineScreenshots = false;
        }
        if (initialColumnSettings.warningTime) {
            this.warningTime = initialColumnSettings.warningTime;
        }
        if (initialColumnSettings.dangerTime) {
            this.dangerTime = initialColumnSettings.dangerTime;
        }
    }


    this.chooseAllTypes = function () {
        var value = true;
        $scope.searchSettings.allselected = !$scope.searchSettings.allselected;
        if (!$scope.searchSettings.allselected) {
            value = false;
        }

        $scope.searchSettings.passed = value;
        $scope.searchSettings.failed = value;
        $scope.searchSettings.pending = value;
        $scope.searchSettings.withLog = value;
    };

    this.isValueAnArray = function (val) {
        return isValueAnArray(val);
    };

    this.getParent = function (str) {
        return getParent(str);
    };

    this.getSpec = function (str) {
        return getSpec(str);
    };

    this.getShortDescription = function (str) {
        return getShortDescription(str);
    };
    this.hasNextScreenshot = function (index) {
        var old = index;
        return old !== this.getNextScreenshotIdx(index);
    };

    this.hasPreviousScreenshot = function (index) {
        var old = index;
        return old !== this.getPreviousScreenshotIdx(index);
    };
    this.getNextScreenshotIdx = function (index) {
        var next = index;
        var hit = false;
        while (next + 2 < this.results.length) {
            next++;
            if (this.results[next].screenShotFile && !this.results[next].pending) {
                hit = true;
                break;
            }
        }
        return hit ? next : index;
    };

    this.getPreviousScreenshotIdx = function (index) {
        var prev = index;
        var hit = false;
        while (prev > 0) {
            prev--;
            if (this.results[prev].screenShotFile && !this.results[prev].pending) {
                hit = true;
                break;
            }
        }
        return hit ? prev : index;
    };

    this.convertTimestamp = convertTimestamp;


    this.round = function (number, roundVal) {
        return (parseFloat(number) / 1000).toFixed(roundVal);
    };


    this.passCount = function () {
        var passCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.passed) {
                passCount++;
            }
        }
        return passCount;
    };


    this.pendingCount = function () {
        var pendingCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.pending) {
                pendingCount++;
            }
        }
        return pendingCount;
    };

    this.failCount = function () {
        var failCount = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (!result.passed && !result.pending) {
                failCount++;
            }
        }
        return failCount;
    };

    this.totalDuration = function () {
        var sum = 0;
        for (var i in this.results) {
            var result = this.results[i];
            if (result.duration) {
                sum += result.duration;
            }
        }
        return sum;
    };

    this.passPerc = function () {
        return (this.passCount() / this.totalCount()) * 100;
    };
    this.pendingPerc = function () {
        return (this.pendingCount() / this.totalCount()) * 100;
    };
    this.failPerc = function () {
        return (this.failCount() / this.totalCount()) * 100;
    };
    this.totalCount = function () {
        return this.passCount() + this.failCount() + this.pendingCount();
    };


    var results = [
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "97ba67acd590c32899dc1bf5bc69a31f",
        "instanceId": 54616,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL."
        ],
        "trace": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at ontimeout (timers.js:436:11)\n    at tryOnTimeout (timers.js:300:5)\n    at listOnTimeout (timers.js:263:5)\n    at Timer.processTimers (timers.js:223:10)",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at ontimeout (timers.js:436:11)\n    at tryOnTimeout (timers.js:300:5)\n    at listOnTimeout (timers.js:263:5)\n    at Timer.processTimers (timers.js:223:10)"
        ],
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593425514016,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2912509)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2912438)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2897560)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:23949)",
                "timestamp": 1593425514189,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593425514858,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:3246224 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593425514869,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:4609755)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:4652626)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:3245281)",
                "timestamp": 1593425514871,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=cf45252e-aa5c-437b-8777-c6dcbe3c8724&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593425554815,
                "type": ""
            }
        ],
        "screenShotFile": "002000b0-0071-00c5-006a-0037002f000a.png",
        "timestamp": 1593425494717,
        "duration": 60067
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "97ba67acd590c32899dc1bf5bc69a31f",
        "instanceId": 54616,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593425555560,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2912509)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2912438)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2897560)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.adf473ff3ddc740dfacc.bundle.js:1:23949)",
                "timestamp": 1593425555722,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593425556240,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593425556241,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:3246224 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593425556241,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:4609755)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:4652626)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js:1:3245281)",
                "timestamp": 1593425556242,
                "type": ""
            }
        ],
        "screenShotFile": "004c0078-000e-00c5-00fd-00900082009a.png",
        "timestamp": 1593425557492,
        "duration": 16060
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "97ba67acd590c32899dc1bf5bc69a31f",
        "instanceId": 54616,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593425573970,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.1c8e5c9b0d846e2be100.bundle.js 0:3246224 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593425573970,
                "type": ""
            }
        ],
        "screenShotFile": "004d003c-0092-00ba-006a-000500bf003f.png",
        "timestamp": 1593425573959,
        "duration": 9462
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "f32b2eba6a69314e78cb78d04ab733c3",
        "instanceId": 23760,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL."
        ],
        "trace": [
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at ontimeout (timers.js:436:11)\n    at tryOnTimeout (timers.js:300:5)\n    at listOnTimeout (timers.js:263:5)\n    at Timer.processTimers (timers.js:223:10)",
            "Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL.\n    at Timeout._onTimeout (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4281:23)\n    at ontimeout (timers.js:436:11)\n    at tryOnTimeout (timers.js:300:5)\n    at listOnTimeout (timers.js:263:5)\n    at Timer.processTimers (timers.js:223:10)"
        ],
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593429686078,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593429686243,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593429686929,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593429686936,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593429686938,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=9b058251-b95b-49cc-94eb-5ff6ebbcd6ba&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593429724729,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593429724729,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593429724730,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593429724730,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593429724730,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593429724731,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593429724731,
                "type": ""
            }
        ],
        "screenShotFile": "008600b6-009e-0088-00a6-006f002200a9.png",
        "timestamp": 1593429664697,
        "duration": 60017
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "f32b2eba6a69314e78cb78d04ab733c3",
        "instanceId": 23760,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00e5006e-00ed-00fe-0021-00d70077003b.png",
        "timestamp": 1593429726767,
        "duration": 15957
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "f32b2eba6a69314e78cb78d04ab733c3",
        "instanceId": 23760,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593429743121,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593429743121,
                "type": ""
            }
        ],
        "screenShotFile": "0075008e-0038-0027-0099-004a002e0067.png",
        "timestamp": 1593429743110,
        "duration": 9436
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4ee78c9cb797e366c0e9aceab913ac26",
        "instanceId": 13608,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593430051271,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593430051466,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593430051935,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430051935,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593430051935,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=a6103c3c-99dd-4e76-9675-64055b50b735&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593430097113,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593430097114,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593430097114,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593430097115,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430097115,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593430097115,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593430097115,
                "type": ""
            }
        ],
        "screenShotFile": "001700b6-0086-00c6-0091-009100b40002.png",
        "timestamp": 1593430032445,
        "duration": 64653
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4ee78c9cb797e366c0e9aceab913ac26",
        "instanceId": 13608,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00ca00fb-0003-00f1-001d-003400280077.png",
        "timestamp": 1593430099116,
        "duration": 15940
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4ee78c9cb797e366c0e9aceab913ac26",
        "instanceId": 13608,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593430115360,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430115360,
                "type": ""
            }
        ],
        "screenShotFile": "00c300aa-001e-0009-00a7-00b400f900ef.png",
        "timestamp": 1593430115438,
        "duration": 9438
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "0464714ac8f604e3c45e8ca3e7a053dc",
        "instanceId": 51868,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593430229513,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593430229678,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593430230326,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430230334,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593430230335,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=562a9557-ebbe-45ed-ad28-32fbb37323db&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593430275395,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593430275396,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593430275397,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593430275397,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430275397,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593430275397,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593430275397,
                "type": ""
            }
        ],
        "screenShotFile": "00de006f-0012-0030-007f-00de00af008f.png",
        "timestamp": 1593430209653,
        "duration": 65722
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "0464714ac8f604e3c45e8ca3e7a053dc",
        "instanceId": 51868,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "001900dd-0061-0020-00a0-001c00b800a5.png",
        "timestamp": 1593430277401,
        "duration": 15967
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "0464714ac8f604e3c45e8ca3e7a053dc",
        "instanceId": 51868,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593430293672,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593430293672,
                "type": ""
            }
        ],
        "screenShotFile": "000400ef-004a-0072-0025-00da00270013.png",
        "timestamp": 1593430293797,
        "duration": 9487
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "adf5b4bdbd272e5254565f123ab5099f",
        "instanceId": 27428,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593451328866,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593451329040,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593451329487,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593451329496,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593451329497,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=8c3d0b19-f7cc-4863-b873-c92fbeb93ff6&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593451374997,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593451374998,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593451374998,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593451374998,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593451374999,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593451374999,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593451374999,
                "type": ""
            }
        ],
        "screenShotFile": "00840067-0006-006d-008e-0023006c0016.png",
        "timestamp": 1593451310067,
        "duration": 64915
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "adf5b4bdbd272e5254565f123ab5099f",
        "instanceId": 27428,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00a40038-0001-0016-0085-006900c900df.png",
        "timestamp": 1593451377434,
        "duration": 15951
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "adf5b4bdbd272e5254565f123ab5099f",
        "instanceId": 27428,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593451393615,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593451393702,
                "type": ""
            }
        ],
        "screenShotFile": "00c2005b-0038-007c-00f5-005200db0020.png",
        "timestamp": 1593451393792,
        "duration": 9442
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "49bca16be3c013a20024f10593e7c135",
        "instanceId": 54368,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Failed: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown"
        ],
        "trace": [
            "NoSuchWindowError: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown\n    at Object.checkLegacyResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\error.js:546:15)\n    at parseHttpResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:509:13)\n    at doSend.then.response (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:441:30)\n    at process._tickCallback (internal/process/next_tick.js:68:7)\nFrom: Task: WebDriver.findElements(By(css selector, *[id=\"username\"]))\n    at thenableWebDriverProxy.schedule (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:807:17)\n    at thenableWebDriverProxy.findElements (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:1048:19)\n    at ptor.waitForAngular.then (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:159:44)\n    at ManagedPromise.invokeCallback_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1376:14)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\n    at asyncRun (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2927:27)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:668:7Error\n    at ElementArrayFinder.applyAction_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:459:27)\n    at ElementArrayFinder.(anonymous function).args [as sendKeys] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:91:29)\n    at ElementFinder.(anonymous function).args [as sendKeys] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:831:22)\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:16:20)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:112:25\n    at new ManagedPromise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1077:7)\n    at ControlFlow.promise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2505:12)\n    at schedulerExecute (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:95:18)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\nFrom: Task: Run it(\"HomePageTest - It should navigate to WCWR home page!\") in control flow\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:94:19)\n    at attempt (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4297:26)\n    at QueueRunner.run (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4217:20)\n    at runNext (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4257:20)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4264:13\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4172:9\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:64:48\n    at ControlFlow.emit (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\events.js:62:21)\n    at ControlFlow.shutdown_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2674:10)\n    at shutdownTask_.MicroTask (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2599:53)\nFrom asynchronous test: \nError\n    at Suite.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:9:3)\n    at addSpecsToSuite (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1107:25)\n    at Env.describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1074:7)\n    at describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4399:18)\n    at Object.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:6:1)\n    at Module._compile (internal/modules/cjs/loader.js:689:30)\n    at Object.Module._extensions..js (internal/modules/cjs/loader.js:700:10)\n    at Module.load (internal/modules/cjs/loader.js:599:32)\n    at tryModuleLoad (internal/modules/cjs/loader.js:538:12)"
        ],
        "browserLogs": [],
        "timestamp": 1593456971384,
        "duration": 12368
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "49bca16be3c013a20024f10593e7c135",
        "instanceId": 54368,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Failed: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown"
        ],
        "trace": [
            "NoSuchWindowError: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown\n    at Object.checkLegacyResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\error.js:546:15)\n    at parseHttpResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:509:13)\n    at doSend.then.response (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:441:30)\n    at process._tickCallback (internal/process/next_tick.js:68:7)\nFrom: Task: WebDriver.findElements(By(xpath, /html/body/app-root/div/div/div[1]/ul[1]/li[2]/a))\n    at thenableWebDriverProxy.schedule (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:807:17)\n    at thenableWebDriverProxy.findElements (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:1048:19)\n    at ptor.waitForAngular.then (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:159:44)\n    at ManagedPromise.invokeCallback_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1376:14)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\n    at asyncRun (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2927:27)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:668:7\n    at process._tickCallback (internal/process/next_tick.js:68:7)Error\n    at ElementArrayFinder.applyAction_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:459:27)\n    at ElementArrayFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:91:29)\n    at ElementFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:831:22)\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:35:29)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:112:25\n    at new ManagedPromise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1077:7)\n    at ControlFlow.promise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2505:12)\n    at schedulerExecute (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:95:18)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\nFrom: Task: Run it(\"HomePageTest - It should Add New Role!\") in control flow\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:94:19)\n    at attempt (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4297:26)\n    at QueueRunner.run (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4217:20)\n    at runNext (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4257:20)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4264:13\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4172:9\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:64:48\n    at ControlFlow.emit (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\events.js:62:21)\n    at ControlFlow.shutdown_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2674:10)\n    at shutdownTask_.MicroTask (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2599:53)\nFrom asynchronous test: \nError\n    at Suite.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:31:3)\n    at addSpecsToSuite (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1107:25)\n    at Env.describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1074:7)\n    at describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4399:18)\n    at Object.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:6:1)\n    at Module._compile (internal/modules/cjs/loader.js:689:30)\n    at Object.Module._extensions..js (internal/modules/cjs/loader.js:700:10)\n    at Module.load (internal/modules/cjs/loader.js:599:32)\n    at tryModuleLoad (internal/modules/cjs/loader.js:538:12)"
        ],
        "browserLogs": [],
        "timestamp": 1593456985824,
        "duration": 19
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "49bca16be3c013a20024f10593e7c135",
        "instanceId": 54368,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Failed: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown"
        ],
        "trace": [
            "NoSuchWindowError: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown\n    at Object.checkLegacyResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\error.js:546:15)\n    at parseHttpResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:509:13)\n    at doSend.then.response (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:441:30)\n    at process._tickCallback (internal/process/next_tick.js:68:7)\nFrom: Task: WebDriver.findElements(By(xpath, /html/body/app-root/div/div/div[1]/ul[1]/li[7]/a))\n    at thenableWebDriverProxy.schedule (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:807:17)\n    at thenableWebDriverProxy.findElements (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:1048:19)\n    at ptor.waitForAngular.then (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:159:44)\n    at ManagedPromise.invokeCallback_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1376:14)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\n    at asyncRun (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2927:27)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:668:7\n    at process._tickCallback (internal/process/next_tick.js:68:7)Error\n    at ElementArrayFinder.applyAction_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:459:27)\n    at ElementArrayFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:91:29)\n    at ElementFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:831:22)\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:54:25)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:112:25\n    at new ManagedPromise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1077:7)\n    at ControlFlow.promise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2505:12)\n    at schedulerExecute (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:95:18)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\nFrom: Task: Run it(\"HomePageTest - It should add Case Type\") in control flow\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:94:19)\n    at attempt (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4297:26)\n    at QueueRunner.run (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4217:20)\n    at runNext (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4257:20)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4264:13\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4172:9\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:64:48\n    at ControlFlow.emit (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\events.js:62:21)\n    at ControlFlow.shutdown_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2674:10)\n    at shutdownTask_.MicroTask (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2599:53)\nFrom asynchronous test: \nError\n    at Suite.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:52:3)\n    at addSpecsToSuite (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1107:25)\n    at Env.describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1074:7)\n    at describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4399:18)\n    at Object.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:6:1)\n    at Module._compile (internal/modules/cjs/loader.js:689:30)\n    at Object.Module._extensions..js (internal/modules/cjs/loader.js:700:10)\n    at Module.load (internal/modules/cjs/loader.js:599:32)\n    at tryModuleLoad (internal/modules/cjs/loader.js:538:12)"
        ],
        "browserLogs": [],
        "timestamp": 1593456985913,
        "duration": 21
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "b8fd2235693ec52d0bf34c669d77724a",
        "instanceId": 55572,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593458393944,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593458394104,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593458394547,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593458394554,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593458394556,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=ac7ba777-8a0e-4f67-bcff-4c734fb3cb68&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593458440281,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593458440281,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593458440282,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593458440282,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593458440283,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593458440283,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593458440283,
                "type": ""
            }
        ],
        "screenShotFile": "006c0007-006f-0064-0091-001b001200cb.png",
        "timestamp": 1593458375047,
        "duration": 65209
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "b8fd2235693ec52d0bf34c669d77724a",
        "instanceId": 55572,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00120004-0002-00ab-00e9-000100ce00db.png",
        "timestamp": 1593458442504,
        "duration": 16020
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "b8fd2235693ec52d0bf34c669d77724a",
        "instanceId": 55572,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593458458754,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593458458762,
                "type": ""
            }
        ],
        "screenShotFile": "0057007b-0000-0098-004f-005000870083.png",
        "timestamp": 1593458458957,
        "duration": 9450
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4036f320572fb5d0b80452fc57124027",
        "instanceId": 27068,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593493136173,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593493136347,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593493136786,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593493136792,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593493136795,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=1117e184-57ef-470d-b26b-2869621bb93f&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593493182419,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593493182419,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593493182420,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593493182420,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593493182420,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593493182420,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593493182421,
                "type": ""
            }
        ],
        "screenShotFile": "00c400ff-0080-006d-00b0-00db00110052.png",
        "timestamp": 1593493117120,
        "duration": 65274
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4036f320572fb5d0b80452fc57124027",
        "instanceId": 27068,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00da003e-008c-0014-00a3-000c00bd0098.png",
        "timestamp": 1593493184875,
        "duration": 16052
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4036f320572fb5d0b80452fc57124027",
        "instanceId": 27068,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593493201162,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593493201172,
                "type": ""
            }
        ],
        "screenShotFile": "009c0036-006f-0075-0071-00b7009f009b.png",
        "timestamp": 1593493201364,
        "duration": 9487
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4dbb92a96d5d66495c492b84a9abf4f5",
        "instanceId": 27784,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593498665858,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593498666028,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593498666498,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593498666500,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593498666501,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=f2255176-8c4d-4d4f-bac2-2b73e80e521c&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593498711694,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593498711695,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593498711695,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593498711696,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593498711696,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593498711696,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593498711696,
                "type": ""
            }
        ],
        "screenShotFile": "00d200a0-0057-0063-00c0-006700af0055.png",
        "timestamp": 1593498646954,
        "duration": 64725
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4dbb92a96d5d66495c492b84a9abf4f5",
        "instanceId": 27784,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "00bd00f1-00b4-00c6-0049-00fe00cc004e.png",
        "timestamp": 1593498713819,
        "duration": 16016
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "4dbb92a96d5d66495c492b84a9abf4f5",
        "instanceId": 27784,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//role/addOrUpdate - Failed to load resource: the server responded with a status of 500 (Internal Server Error)",
                "timestamp": 1593498730177,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593498730177,
                "type": ""
            }
        ],
        "screenShotFile": "00320014-0079-0091-001d-006500dc0014.png",
        "timestamp": 1593498730286,
        "duration": 9493
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3bbc3fdb19ccef65bd814842a80fa61f",
        "instanceId": 38436,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593517208596,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593517208760,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593517209218,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593517209223,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593517209226,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=19bf4f5c-241d-4aa8-826a-63899e6622a2&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593517256556,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593517256557,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593517256557,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593517256558,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593517256558,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593517256558,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593517256558,
                "type": ""
            }
        ],
        "screenShotFile": "008f00c1-008e-0059-00a7-00a700270097.png",
        "timestamp": 1593517188129,
        "duration": 68411
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": false,
        "pending": false,
        "os": "windows",
        "sessionId": "3bbc3fdb19ccef65bd814842a80fa61f",
        "instanceId": 38436,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": [
            "Failed: element click intercepted: Element <button _ngcontent-c3=\"\" class=\"float-right\" type=\"button\">...</button> is not clickable at point (1239, 33). Other element would receive the click: <h1 _ngcontent-c3=\"\">...</h1>\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown"
        ],
        "trace": [
            "WebDriverError: element click intercepted: Element <button _ngcontent-c3=\"\" class=\"float-right\" type=\"button\">...</button> is not clickable at point (1239, 33). Other element would receive the click: <h1 _ngcontent-c3=\"\">...</h1>\n  (Session info: chrome=83.0.4103.116)\nBuild info: version: '3.141.59', revision: 'e82be7d358', time: '2018-11-14T08:25:53'\nSystem info: host: 'SP2DEVVDITCM032', ip: '10.25.71.41', os.name: 'Windows 7', os.arch: 'amd64', os.version: '6.1', java.version: '1.8.0_231'\nDriver info: driver.version: unknown\n    at Object.checkLegacyResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\error.js:546:15)\n    at parseHttpResponse (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:509:13)\n    at doSend.then.response (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\http.js:441:30)\n    at process._tickCallback (internal/process/next_tick.js:68:7)\nFrom: Task: WebElement.click()\n    at thenableWebDriverProxy.schedule (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:807:17)\n    at WebElement.schedule_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:2010:25)\n    at WebElement.click (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\webdriver.js:2092:17)\n    at actionFn (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:89:44)\n    at Array.map (<anonymous>)\n    at actionResults.getWebElements.then (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:461:65)\n    at ManagedPromise.invokeCallback_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1376:14)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\n    at asyncRun (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2927:27)Error\n    at ElementArrayFinder.applyAction_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:459:27)\n    at ElementArrayFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:91:29)\n    at ElementFinder.(anonymous function).args [as click] (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\built\\element.js:831:22)\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:37:31)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:112:25\n    at new ManagedPromise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:1077:7)\n    at ControlFlow.promise (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2505:12)\n    at schedulerExecute (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:95:18)\n    at TaskQueue.execute_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3084:14)\n    at TaskQueue.executeNext_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:3067:27)\nFrom: Task: Run it(\"HomePageTest - It should Add New Role!\") in control flow\n    at UserContext.<anonymous> (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:94:19)\n    at attempt (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4297:26)\n    at QueueRunner.run (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4217:20)\n    at runNext (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4257:20)\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4264:13\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4172:9\n    at C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasminewd2\\index.js:64:48\n    at ControlFlow.emit (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\events.js:62:21)\n    at ControlFlow.shutdown_ (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2674:10)\n    at shutdownTask_.MicroTask (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\selenium-webdriver\\lib\\promise.js:2599:53)\nFrom asynchronous test: \nError\n    at Suite.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:31:3)\n    at addSpecsToSuite (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1107:25)\n    at Env.describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:1074:7)\n    at describe (C:\\Users\\UX013810\\AppData\\Roaming\\npm\\node_modules\\protractor\\node_modules\\jasmine-core\\lib\\jasmine-core\\jasmine.js:4399:18)\n    at Object.<anonymous> (C:\\Users\\UX013810\\workspace\\Poc_Wcwrui\\Tests\\HomePageTest.js:6:1)\n    at Module._compile (internal/modules/cjs/loader.js:689:30)\n    at Object.Module._extensions..js (internal/modules/cjs/loader.js:700:10)\n    at Module.load (internal/modules/cjs/loader.js:599:32)\n    at tryModuleLoad (internal/modules/cjs/loader.js:538:12)"
        ],
        "browserLogs": [],
        "screenShotFile": "00970077-0096-0049-0064-004d00b90076.png",
        "timestamp": 1593517258797,
        "duration": 4360
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "3bbc3fdb19ccef65bd814842a80fa61f",
        "instanceId": 38436,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "003800ae-00ac-00dd-00f4-00e300cc00e4.png",
        "timestamp": 1593517263561,
        "duration": 9408
    },
    {
        "description": "HomePageTest - It should navigate to WCWR home page!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "6555364934e1fc5f10f7155e84008513",
        "instanceId": 59044,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593576921971,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593576922136,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593576922796,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593576922803,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593576922805,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://authenticator.pingone.com/pingid/ppm/auth/response?csrfToken=0987278d-7dfa-4e04-b8e6-289a025a05fe&status=OK&getStatusResponse=%7B%22status%22%3A%22OK%22%7D - A cookie associated with a cross-site resource at http://sso.thomsonreuters.com/ was set without the `SameSite` attribute. A future release of Chrome will only deliver cookies with cross-site requests if they are set with `SameSite=None` and `Secure`. You can review cookies in developer tools under Application>Storage>Cookies and see more details at https://www.chromestatus.com/feature/5088147346030592 and https://www.chromestatus.com/feature/5633521622188032.",
                "timestamp": 1593576968260,
                "type": ""
            },
            {
                "level": "WARNING",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0 The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.",
                "timestamp": 1593576968260,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" Error: Uncaught (in promise): Error: Cannot match any routes. URL Segment: 'users'\nError: Cannot match any routes. URL Segment: 'users'\n    at e.noMatchError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2912017)\n    at t.selector (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2911946)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2897068)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35354)\n    at i (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35063)\n    at https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:35885\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31709)\n    at Object.onInvokeTask (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1634983)\n    at e.invokeTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:31630)\n    at r.runTask (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:26887)\n    at o (https://test.westlawcourtwire.thomson.com/wcwr/polyfills.e3ce8e79cc94b9e0c698.bundle.js:1:23949)",
                "timestamp": 1593576968261,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/favicon.ico - Failed to load resource: the server responded with a status of 404 (Not Found)",
                "timestamp": 1593576968261,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr//rest//file/checkUserImageExist?&userId=undefined - Failed to load resource: the server responded with a status of 400 (Bad Request)",
                "timestamp": 1593576968261,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:3245732 \"Data Service - Handle Error -> \" Object",
                "timestamp": 1593576968261,
                "type": ""
            },
            {
                "level": "SEVERE",
                "message": "https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js 0:1621268 \"ERROR\" TypeError: Cannot read property 'url' of undefined\n    at https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2690416\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:2773957)\n    at t.__tryOrUnsub (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1107282)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1106769)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105698)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t.notifyError (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4609263)\n    at t._error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:4652134)\n    at t.error (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:1105392)\n    at t._subscribe (https://test.westlawcourtwire.thomson.com/wcwr/main.495ef5315c783d03710a.bundle.js:1:3244789)",
                "timestamp": 1593576968262,
                "type": ""
            }
        ],
        "screenShotFile": "006600e0-0082-005c-000a-000000d60090.png",
        "timestamp": 1593576901511,
        "duration": 66734
    },
    {
        "description": "HomePageTest - It should Add New Role!|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "6555364934e1fc5f10f7155e84008513",
        "instanceId": 59044,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "004c00a4-002d-005a-0060-0067008700ac.png",
        "timestamp": 1593576970660,
        "duration": 16521
    },
    {
        "description": "HomePageTest - It should add Case Type|WCWRUI Homepage",
        "passed": true,
        "pending": false,
        "os": "windows",
        "sessionId": "6555364934e1fc5f10f7155e84008513",
        "instanceId": 59044,
        "browser": {
            "name": "chrome",
            "version": "83.0.4103.116"
        },
        "message": "Passed",
        "browserLogs": [],
        "screenShotFile": "004a002d-00e0-0005-0038-002900ce00ad.png",
        "timestamp": 1593576987605,
        "duration": 9479
    }
];

    this.sortSpecs = function () {
        this.results = results.sort(function sortFunction(a, b) {
    if (a.sessionId < b.sessionId) return -1;else if (a.sessionId > b.sessionId) return 1;

    if (a.timestamp < b.timestamp) return -1;else if (a.timestamp > b.timestamp) return 1;

    return 0;
});

    };

    this.setTitle = function () {
        var title = $('.report-title').text();
        titleService.setTitle(title);
    };

    // is run after all test data has been prepared/loaded
    this.afterLoadingJobs = function () {
        this.sortSpecs();
        this.setTitle();
    };

    this.loadResultsViaAjax = function () {

        $http({
            url: './combined.json',
            method: 'GET'
        }).then(function (response) {
                var data = null;
                if (response && response.data) {
                    if (typeof response.data === 'object') {
                        data = response.data;
                    } else if (response.data[0] === '"') { //detect super escaped file (from circular json)
                        data = CircularJSON.parse(response.data); //the file is escaped in a weird way (with circular json)
                    } else {
                        data = JSON.parse(response.data);
                    }
                }
                if (data) {
                    results = data;
                    that.afterLoadingJobs();
                }
            },
            function (error) {
                console.error(error);
            });
    };


    if (clientDefaults.useAjax) {
        this.loadResultsViaAjax();
    } else {
        this.afterLoadingJobs();
    }

}]);

app.filter('bySearchSettings', function () {
    return function (items, searchSettings) {
        var filtered = [];
        if (!items) {
            return filtered; // to avoid crashing in where results might be empty
        }
        var prevItem = null;

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            item.displaySpecName = false;

            var isHit = false; //is set to true if any of the search criteria matched
            countLogMessages(item); // modifies item contents

            var hasLog = searchSettings.withLog && item.browserLogs && item.browserLogs.length > 0;
            if (searchSettings.description === '' ||
                (item.description && item.description.toLowerCase().indexOf(searchSettings.description.toLowerCase()) > -1)) {

                if (searchSettings.passed && item.passed || hasLog) {
                    isHit = true;
                } else if (searchSettings.failed && !item.passed && !item.pending || hasLog) {
                    isHit = true;
                } else if (searchSettings.pending && item.pending || hasLog) {
                    isHit = true;
                }
            }
            if (isHit) {
                checkIfShouldDisplaySpecName(prevItem, item);

                filtered.push(item);
                prevItem = item;
            }
        }

        return filtered;
    };
});

//formats millseconds to h m s
app.filter('timeFormat', function () {
    return function (tr, fmt) {
        if(tr == null){
            return "NaN";
        }

        switch (fmt) {
            case 'h':
                var h = tr / 1000 / 60 / 60;
                return "".concat(h.toFixed(2)).concat("h");
            case 'm':
                var m = tr / 1000 / 60;
                return "".concat(m.toFixed(2)).concat("min");
            case 's' :
                var s = tr / 1000;
                return "".concat(s.toFixed(2)).concat("s");
            case 'hm':
            case 'h:m':
                var hmMt = tr / 1000 / 60;
                var hmHr = Math.trunc(hmMt / 60);
                var hmMr = hmMt - (hmHr * 60);
                if (fmt === 'h:m') {
                    return "".concat(hmHr).concat(":").concat(hmMr < 10 ? "0" : "").concat(Math.round(hmMr));
                }
                return "".concat(hmHr).concat("h ").concat(hmMr.toFixed(2)).concat("min");
            case 'hms':
            case 'h:m:s':
                var hmsS = tr / 1000;
                var hmsHr = Math.trunc(hmsS / 60 / 60);
                var hmsM = hmsS / 60;
                var hmsMr = Math.trunc(hmsM - hmsHr * 60);
                var hmsSo = hmsS - (hmsHr * 60 * 60) - (hmsMr*60);
                if (fmt === 'h:m:s') {
                    return "".concat(hmsHr).concat(":").concat(hmsMr < 10 ? "0" : "").concat(hmsMr).concat(":").concat(hmsSo < 10 ? "0" : "").concat(Math.round(hmsSo));
                }
                return "".concat(hmsHr).concat("h ").concat(hmsMr).concat("min ").concat(hmsSo.toFixed(2)).concat("s");
            case 'ms':
                var msS = tr / 1000;
                var msMr = Math.trunc(msS / 60);
                var msMs = msS - (msMr * 60);
                return "".concat(msMr).concat("min ").concat(msMs.toFixed(2)).concat("s");
        }

        return tr;
    };
});


function PbrStackModalController($scope, $rootScope) {
    var ctrl = this;
    ctrl.rootScope = $rootScope;
    ctrl.getParent = getParent;
    ctrl.getShortDescription = getShortDescription;
    ctrl.convertTimestamp = convertTimestamp;
    ctrl.isValueAnArray = isValueAnArray;
    ctrl.toggleSmartStackTraceHighlight = function () {
        var inv = !ctrl.rootScope.showSmartStackTraceHighlight;
        ctrl.rootScope.showSmartStackTraceHighlight = inv;
    };
    ctrl.applySmartHighlight = function (line) {
        if ($rootScope.showSmartStackTraceHighlight) {
            if (line.indexOf('node_modules') > -1) {
                return 'greyout';
            }
            if (line.indexOf('  at ') === -1) {
                return '';
            }

            return 'highlight';
        }
        return '';
    };
}


app.component('pbrStackModal', {
    templateUrl: "pbr-stack-modal.html",
    bindings: {
        index: '=',
        data: '='
    },
    controller: PbrStackModalController
});

function PbrScreenshotModalController($scope, $rootScope) {
    var ctrl = this;
    ctrl.rootScope = $rootScope;
    ctrl.getParent = getParent;
    ctrl.getShortDescription = getShortDescription;

    /**
     * Updates which modal is selected.
     */
    this.updateSelectedModal = function (event, index) {
        var key = event.key; //try to use non-deprecated key first https://developer.mozilla.org/de/docs/Web/API/KeyboardEvent/keyCode
        if (key == null) {
            var keyMap = {
                37: 'ArrowLeft',
                39: 'ArrowRight'
            };
            key = keyMap[event.keyCode]; //fallback to keycode
        }
        if (key === "ArrowLeft" && this.hasPrevious) {
            this.showHideModal(index, this.previous);
        } else if (key === "ArrowRight" && this.hasNext) {
            this.showHideModal(index, this.next);
        }
    };

    /**
     * Hides the modal with the #oldIndex and shows the modal with the #newIndex.
     */
    this.showHideModal = function (oldIndex, newIndex) {
        const modalName = '#imageModal';
        $(modalName + oldIndex).modal("hide");
        $(modalName + newIndex).modal("show");
    };

}

app.component('pbrScreenshotModal', {
    templateUrl: "pbr-screenshot-modal.html",
    bindings: {
        index: '=',
        data: '=',
        next: '=',
        previous: '=',
        hasNext: '=',
        hasPrevious: '='
    },
    controller: PbrScreenshotModalController
});

app.factory('TitleService', ['$document', function ($document) {
    return {
        setTitle: function (title) {
            $document[0].title = title;
        }
    };
}]);


app.run(
    function ($rootScope, $templateCache) {
        //make sure this option is on by default
        $rootScope.showSmartStackTraceHighlight = true;
        
  $templateCache.put('pbr-screenshot-modal.html',
    '<div class="modal" id="imageModal{{$ctrl.index}}" tabindex="-1" role="dialog"\n' +
    '     aria-labelledby="imageModalLabel{{$ctrl.index}}" ng-keydown="$ctrl.updateSelectedModal($event,$ctrl.index)">\n' +
    '    <div class="modal-dialog modal-lg m-screenhot-modal" role="document">\n' +
    '        <div class="modal-content">\n' +
    '            <div class="modal-header">\n' +
    '                <button type="button" class="close" data-dismiss="modal" aria-label="Close">\n' +
    '                    <span aria-hidden="true">&times;</span>\n' +
    '                </button>\n' +
    '                <h6 class="modal-title" id="imageModalLabelP{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getParent($ctrl.data.description)}}</h6>\n' +
    '                <h5 class="modal-title" id="imageModalLabel{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getShortDescription($ctrl.data.description)}}</h5>\n' +
    '            </div>\n' +
    '            <div class="modal-body">\n' +
    '                <img class="screenshotImage" ng-src="{{$ctrl.data.screenShotFile}}">\n' +
    '            </div>\n' +
    '            <div class="modal-footer">\n' +
    '                <div class="pull-left">\n' +
    '                    <button ng-disabled="!$ctrl.hasPrevious" class="btn btn-default btn-previous" data-dismiss="modal"\n' +
    '                            data-toggle="modal" data-target="#imageModal{{$ctrl.previous}}">\n' +
    '                        Prev\n' +
    '                    </button>\n' +
    '                    <button ng-disabled="!$ctrl.hasNext" class="btn btn-default btn-next"\n' +
    '                            data-dismiss="modal" data-toggle="modal"\n' +
    '                            data-target="#imageModal{{$ctrl.next}}">\n' +
    '                        Next\n' +
    '                    </button>\n' +
    '                </div>\n' +
    '                <a class="btn btn-primary" href="{{$ctrl.data.screenShotFile}}" target="_blank">\n' +
    '                    Open Image in New Tab\n' +
    '                    <span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>\n' +
    '                </a>\n' +
    '                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '</div>\n' +
     ''
  );

  $templateCache.put('pbr-stack-modal.html',
    '<div class="modal" id="modal{{$ctrl.index}}" tabindex="-1" role="dialog"\n' +
    '     aria-labelledby="stackModalLabel{{$ctrl.index}}">\n' +
    '    <div class="modal-dialog modal-lg m-stack-modal" role="document">\n' +
    '        <div class="modal-content">\n' +
    '            <div class="modal-header">\n' +
    '                <button type="button" class="close" data-dismiss="modal" aria-label="Close">\n' +
    '                    <span aria-hidden="true">&times;</span>\n' +
    '                </button>\n' +
    '                <h6 class="modal-title" id="stackModalLabelP{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getParent($ctrl.data.description)}}</h6>\n' +
    '                <h5 class="modal-title" id="stackModalLabel{{$ctrl.index}}">\n' +
    '                    {{$ctrl.getShortDescription($ctrl.data.description)}}</h5>\n' +
    '            </div>\n' +
    '            <div class="modal-body">\n' +
    '                <div ng-if="$ctrl.data.trace.length > 0">\n' +
    '                    <div ng-if="$ctrl.isValueAnArray($ctrl.data.trace)">\n' +
    '                        <pre class="logContainer" ng-repeat="trace in $ctrl.data.trace track by $index"><div ng-class="$ctrl.applySmartHighlight(line)" ng-repeat="line in trace.split(\'\\n\') track by $index">{{line}}</div></pre>\n' +
    '                    </div>\n' +
    '                    <div ng-if="!$ctrl.isValueAnArray($ctrl.data.trace)">\n' +
    '                        <pre class="logContainer"><div ng-class="$ctrl.applySmartHighlight(line)" ng-repeat="line in $ctrl.data.trace.split(\'\\n\') track by $index">{{line}}</div></pre>\n' +
    '                    </div>\n' +
    '                </div>\n' +
    '                <div ng-if="$ctrl.data.browserLogs.length > 0">\n' +
    '                    <h5 class="modal-title">\n' +
    '                        Browser logs:\n' +
    '                    </h5>\n' +
    '                    <pre class="logContainer"><div class="browserLogItem"\n' +
    '                                                   ng-repeat="logError in $ctrl.data.browserLogs track by $index"><div><span class="label browserLogLabel label-default"\n' +
    '                                                                                                                             ng-class="{\'label-danger\': logError.level===\'SEVERE\', \'label-warning\': logError.level===\'WARNING\'}">{{logError.level}}</span><span class="label label-default">{{$ctrl.convertTimestamp(logError.timestamp)}}</span><div ng-repeat="messageLine in logError.message.split(\'\\\\n\') track by $index">{{ messageLine }}</div></div></div></pre>\n' +
    '                </div>\n' +
    '            </div>\n' +
    '            <div class="modal-footer">\n' +
    '                <button class="btn btn-default"\n' +
    '                        ng-class="{active: $ctrl.rootScope.showSmartStackTraceHighlight}"\n' +
    '                        ng-click="$ctrl.toggleSmartStackTraceHighlight()">\n' +
    '                    <span class="glyphicon glyphicon-education black"></span> Smart Stack Trace\n' +
    '                </button>\n' +
    '                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\n' +
    '            </div>\n' +
    '        </div>\n' +
    '    </div>\n' +
    '</div>\n' +
     ''
  );

    });
